"""
Web Crawler específico para provaderesidencia.com.br
Baseado na estrutura HTML real das páginas de questão.

Estrutura da página:
  div.col-md-6.space10-bottom
    ├── p.alert.alert-warning   → aviso (ex: "QUESTÃO ANULADA"), opcional
    ├── h3                      → número da questão (ex: "Questão 2")
    ├── [text node]             → enunciado da questão
    ├── img.img-responsive      → imagem do enunciado, opcional
    └── form[method=post]
          ├── input[csrfmiddlewaretoken]
          └── div.radio [.alert-success | .alert-danger]
                └── label
                      └── input[type=radio, name=choice, value=<id>]

Sinais de gabarito:
  - div.radio.alert-success  → alternativa CORRETA (gabarito oficial)
  - div.radio.alert-danger   → alternativa escolhida pelo usuário (pode ser errada)
  - input[checked]           → alternativa que o usuário marcou
  - input[disabled]          → questão já foi respondida (modo revisão)
  - sem alert-success/danger → questão ainda não respondida

Dados salvos por questão:
  - prova, numero, enunciado, aviso_anulacao
  - alternativas (todas, com letra, texto, id, flag correta)
  - alternativa_correta (valor do input da alternativa com alert-success)
  - estado: "respondida" | "nao_respondida" | "anulada"

A resposta escolhida aleatoriamente NÃO é armazenada.
"""

import requests
from bs4 import BeautifulSoup, NavigableString
from urllib.parse import urljoin, urlparse
import json
import random
import time
import re
import logging
import os
from datetime import datetime
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

SCRIPT_DIR = Path(__file__).resolve().parent

def _resolver_arquivo_saida(arquivo_saida: str) -> str:
    """
    Garante que o JSON seja salvo no diretório do script (`arthur/`),
    evitando depender do diretório atual onde o Python foi executado.
    """
    p = Path(arquivo_saida)
    if p.is_absolute():
        return str(p)
    return str(SCRIPT_DIR / p)


# ─────────────────────────────────────────────
# SESSÃO HTTP  (simula navegador para evitar 403)
# ─────────────────────────────────────────────

def _carregar_cookies_de_acesso(sessao: requests.Session) -> None:
    """
    ─────────────────────────────────────────────────────────────────────
    SIMULAÇÃO DE NAVEGADOR (COOKIES DE ACESSO) — AÇÃO EXPLÍCITA E OPCIONAL
    ─────────────────────────────────────────────────────────────────────
    Alguns sites (como o provaderesidencia.com.br) podem exigir cookies de uma
    sessão autenticada/validada para permitir acesso (evitar 403).

    Por segurança, este script NÃO tenta extrair cookies automaticamente do
    navegador desta máquina. Em vez disso, você pode fornecer manualmente
    cookies da SUA PRÓPRIA sessão (com autorização) via variável de ambiente.

    Como usar:
      - Defina `CRAWLER_COOKIE_HEADER` com o conteúdo do header "Cookie"
        (formato: "key1=value1; key2=value2; ...")
      - Opcionalmente, defina `CRAWLER_REFERER` para ajustar o referer.
    """
    cookie_header = os.getenv("CRAWLER_COOKIE_HEADER", "").strip()
    if cookie_header:
        # Aqui "simulamos" o navegador reaproveitando os cookies de sessão.
        sessao.headers.update({"Cookie": cookie_header})

    referer = os.getenv("CRAWLER_REFERER", "").strip()
    if referer:
        sessao.headers.update({"Referer": referer})


def criar_sessao() -> requests.Session:
    sessao = requests.Session()
    # "Simulação" de navegador: headers comuns de browser, keep-alive e compressão.
    sessao.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        # Alguns servidores usam os "Sec-Fetch-*" como heurística simples.
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Referer": "https://provaderesidencia.com.br/",
    })

    # Re-tentativas (retries) para erros transitórios.
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        status=3,
        backoff_factor=0.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=("GET", "POST"),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
    sessao.mount("https://", adapter)
    sessao.mount("http://", adapter)

    # Cookies de acesso (opcional, fornecidos manualmente).
    _carregar_cookies_de_acesso(sessao)
    return sessao


# ─────────────────────────────────────────────
# EXTRAÇÃO DA QUESTÃO  (lógica específica do site)
# ─────────────────────────────────────────────

def _letra_da_alternativa(texto: str) -> str:
    """
    Extrai a letra da alternativa a partir do texto.
    Ex: "A ) texto..." → "A"
    """
    m = re.match(r"^\s*([A-Ea-e])\s*[\)\.]\s*", texto)
    return m.group(1).upper() if m else ""


def extrair_questao(soup: BeautifulSoup, url: str) -> dict | None:
    """
    Extrai todos os dados da questão a partir do HTML da página.
    Retorna None se a estrutura esperada não for encontrada.
    """
    # Coluna principal da questão: div com AMBAS as classes col-md-6 e space10-bottom
    col = soup.find("div", class_=lambda c: c and "col-md-6" in c and "space10-bottom" in c)
    if not col:
        logger.warning(f"Estrutura de questão não encontrada em: {url}")
        return None

    # ── Prova / Banca ────────────────────────────────────────────
    # h2 está FORA do col (no row anterior), mas dentro do mesmo container
    h2 = soup.find("h2")
    prova = h2.get_text(strip=True) if h2 else ""

    # ── Aviso de anulação ────────────────────────────────────────
    aviso_tag = col.find("p", class_=lambda c: c and "alert-warning" in c)
    aviso = aviso_tag.get_text(strip=True) if aviso_tag else None

    # ── Número da questão ────────────────────────────────────────
    h3 = col.find("h3")
    numero = h3.get_text(strip=True) if h3 else ""

    # ── Enunciado (text node imediatamente após o h3) ────────────
    enunciado = ""
    if h3:
        node = h3.next_sibling
        partes = []
        while node:
            # Para quando encontrar o formulário ou imagem — já coletamos o que precisávamos
            if hasattr(node, "name") and node.name in ("form", "img"):
                break
            if isinstance(node, NavigableString):
                s = str(node).strip()
                if s:
                    partes.append(s)
            elif hasattr(node, "get_text"):
                # Pode haver um <p> ou <span> com parte do enunciado
                if node.name not in ("form",):
                    s = node.get_text(strip=True)
                    if s:
                        partes.append(s)
            node = node.next_sibling
        enunciado = " ".join(partes)

    # ── Imagem do enunciado ──────────────────────────────────────
    img_tag = col.find("img", class_=lambda c: c and "img-responsive" in c)
    imagem_enunciado = urljoin(url, img_tag["src"]) if img_tag and img_tag.get("src") else None

    # ── Formulário e CSRF ────────────────────────────────────────
    form = col.find("form", method="post")
    csrf = ""
    if form:
        csrf_inp = form.find("input", attrs={"name": "csrfmiddlewaretoken"})
        csrf = csrf_inp.get("value", "") if csrf_inp else ""

    # ── Alternativas ─────────────────────────────────────────────
    alternativas = []
    gabarito_valor = None   # value do input da alternativa correta
    gabarito_letra = None   # letra da alternativa correta

    divs_radio = col.find_all("div", class_="radio") if form else []

    for div in divs_radio:
        classes_div = set(div.get("class", []))
        inp = div.find("input", type="radio")
        lbl = div.find("label")

        if not inp or not lbl:
            continue

        valor    = inp.get("value", "")
        texto    = lbl.get_text(strip=True)
        letra    = _letra_da_alternativa(texto)
        checked  = inp.has_attr("checked")    # usuário marcou esta
        disabled = inp.has_attr("disabled")   # questão já foi respondida

        # Gabarito = div com classe alert-success
        e_correta = "alert-success" in classes_div

        if e_correta:
            gabarito_valor = valor
            gabarito_letra = letra

        alternativas.append({
            "letra":   letra,
            "valor":   valor,   # id interno do servidor
            "texto":   texto,
            "correta": e_correta,
        })

    # ── Estado da questão ────────────────────────────────────────
    todos_disabled = all(
        a_tag.has_attr("disabled")
        for a_tag in col.find_all("input", type="radio")
    )
    tem_gabarito = gabarito_valor is not None

    if aviso and "ANULADA" in aviso.upper():
        estado = "anulada"
    elif todos_disabled and tem_gabarito:
        estado = "respondida"
    elif todos_disabled and not tem_gabarito:
        # Respondida mas gabarito ainda não exibido (caso raro)
        estado = "respondida_sem_gabarito"
    else:
        estado = "nao_respondida"

    return {
        "url":               url,
        "prova":             prova,
        "numero":            numero,
        "enunciado":         enunciado,
        "imagem_enunciado":  imagem_enunciado,
        "aviso":             aviso,
        "estado":            estado,
        "alternativas":      alternativas,
        "alternativa_correta": {
            "letra": gabarito_letra,
            "valor": gabarito_valor,
        } if gabarito_valor else None,
        "_csrf": csrf,  # necessário para simular POST
    }


# ─────────────────────────────────────────────
# SIMULAÇÃO DE RESPOSTA ALEATÓRIA  (não salva)
# ─────────────────────────────────────────────

def responder_aleatoriamente(questao: dict, sessao: requests.Session) -> None:
    """
    Simula o envio de uma resposta aleatória via POST.
    Para questões não respondidas, escolhe uma alternativa ao acaso e envia.
    O resultado NÃO é armazenado — serve apenas para simular a interação.
    """
    if questao["estado"] != "nao_respondida":
        logger.debug(f"Questão já respondida ou anulada — pulando POST: {questao['url']}")
        return

    alternativas = questao.get("alternativas", [])
    if not alternativas:
        return

    escolhida = random.choice(alternativas)
    csrf = questao.get("_csrf", "")

    payload = {
        "csrfmiddlewaretoken": csrf,
        "choice": escolhida["valor"],
    }

    try:
        r = sessao.post(
            questao["url"],
            data=payload,
            headers={"Referer": questao["url"]},
            timeout=10,
            allow_redirects=True,
        )
        logger.debug(
            f"POST enviado → escolha={escolhida['letra']} | "
            f"status={r.status_code} | url={questao['url']}"
        )
    except requests.RequestException as e:
        logger.warning(f"Erro ao enviar POST: {e}")


# ─────────────────────────────────────────────
# EXTRAÇÃO DE LINKS DE NAVEGAÇÃO
# ─────────────────────────────────────────────

def extrair_links_questoes(soup: BeautifulSoup, url_base: str, dominio: str) -> dict:
    """
    Extrai links de navegação do site:
      - botões Anterior / Próxima
      - tabela lateral de questões da prova
    Retorna dict separando links de questão dos demais links da página.
    """
    links_questao = []
    links_outros  = []
    vistos = set()

    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith("#") or href.startswith("javascript:"):
            continue

        url_completa = urljoin(url_base, href)
        url_limpa = urlparse(url_completa)._replace(fragment="").geturl()

        if url_limpa in vistos:
            continue
        vistos.add(url_limpa)

        texto = a.get_text(strip=True)
        entrada = {"url": url_limpa, "texto": texto}

        # Links de questão seguem o padrão /demo/questao/<id>/<slug>
        if re.search(r"/demo/questao/\d+/", url_limpa):
            links_questao.append(entrada)
        elif urlparse(url_limpa).netloc == dominio:
            links_outros.append(entrada)

    return {
        "questoes": links_questao,   # links diretos para outras questões
        "outros":   links_outros,
        "total":    len(links_questao) + len(links_outros),
    }


# ─────────────────────────────────────────────
# EXTRAÇÃO DE CONTEÚDO GERAL DA PÁGINA
# ─────────────────────────────────────────────

def extrair_headers(soup: BeautifulSoup) -> list:
    resultado = []
    for tag in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"]):
        texto = tag.get_text(strip=True)
        if texto:
            resultado.append({"nivel": tag.name, "texto": texto})
    return resultado


def extrair_imagens(soup: BeautifulSoup, url_base: str) -> list:
    resultado = []
    for img in soup.find_all("img"):
        src = img.get("src", "")
        if src:
            resultado.append({
                "src":    urljoin(url_base, src),
                "alt":    img.get("alt", ""),
                "title":  img.get("title", ""),
                "largura": img.get("width", ""),
                "altura":  img.get("height", ""),
            })
    return resultado


def extrair_textos(soup: BeautifulSoup) -> list:
    resultado = []
    for tag in soup.find_all(["p", "article", "blockquote"]):
        texto = tag.get_text(strip=True)
        if texto and len(texto) > 20:
            resultado.append({"tag": tag.name, "texto": texto[:2000]})
    return resultado


# ─────────────────────────────────────────────
# PROCESSAMENTO DE UMA PÁGINA
# ─────────────────────────────────────────────

def processar_pagina(url: str, sessao: requests.Session) -> dict | None:
    logger.info(f"Acessando: {url}")

    try:
        resp = sessao.get(url, timeout=10)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding
    except requests.RequestException as e:
        logger.error(f"Erro ao acessar {url}: {e}")
        return None

    if "text/html" not in resp.headers.get("Content-Type", ""):
        logger.warning(f"Ignorado (não é HTML): {url}")
        return None

    html_completo = resp.text
    soup = BeautifulSoup(html_completo, "html.parser")
    dominio = urlparse(url).netloc

    titulo_tag = soup.find("title")
    titulo = titulo_tag.get_text(strip=True) if titulo_tag else "Sem título"

    # Extrai dados específicos da questão
    questao = extrair_questao(soup, url)

    # Simula resposta aleatória (resultado descartado — não é salvo)
    if questao:
        responder_aleatoriamente(questao, sessao)
        # Remove o CSRF do objeto antes de salvar (dado operacional, não relevante)
        questao.pop("_csrf", None)

    # Monta o objeto final da página
    dados = {
        "url":         url,
        "titulo":      titulo,
        "dominio":     dominio,
        "timestamp":   datetime.now().isoformat(),
        "status_http": resp.status_code,
        # Conteúdo estruturado da questão
        "questao":     questao,
        # Conteúdo geral da página
        "headers_pagina": extrair_headers(soup),
        "imagens":        extrair_imagens(soup, url),
        "textos":         extrair_textos(soup),
        # Links de navegação
        "links":          extrair_links_questoes(soup, url, dominio),
        # HTML completo
        "html_completo":  html_completo,
    }

    if questao:
        n_alt = len(questao["alternativas"])
        correta = questao["alternativa_correta"]
        logger.info(
            f"  → [{questao['estado']}] {questao['numero']} | "
            f"{n_alt} alternativas | "
            f"correta: {correta['letra'] if correta else 'não exibida'} | "
            f"links de questão: {len(dados['links']['questoes'])}"
        )
    else:
        logger.info(f"  → (página sem questão estruturada)")

    return dados


# ─────────────────────────────────────────────
# CRAWLER PRINCIPAL
# ─────────────────────────────────────────────

def crawl(
    url_inicial: str,
    max_paginas: int = 5,
    delay: float = 1.5,
    apenas_questoes: bool = True,
    arquivo_saida: str = "resultado_crawl.json",
) -> dict:
    """
    Executa o crawler a partir da URL inicial.

    Parâmetros:
        url_inicial    : URL de início (deve ser uma página de questão)
        max_paginas    : Máximo de páginas a visitar
        delay          : Pausa em segundos entre requisições
        apenas_questoes: Se True, segue apenas links /demo/questao/
        arquivo_saida  : Arquivo JSON de saída
    """
    sessao = criar_sessao()
    arquivo_saida = _resolver_arquivo_saida(arquivo_saida)
    dominio_base = urlparse(url_inicial).netloc

    fila = [url_inicial]
    visitados = set()
    paginas_coletadas = []

    logger.info(f"Iniciando crawl em: {url_inicial}")
    logger.info(f"Max páginas: {max_paginas} | Apenas questões: {apenas_questoes}")

    while fila and len(visitados) < max_paginas:
        url_atual = fila.pop(0)

        if url_atual in visitados:
            continue
        visitados.add(url_atual)

        dados = processar_pagina(url_atual, sessao)

        if dados:
            paginas_coletadas.append(dados)

            # Adiciona links de questão à fila
            for link_info in dados["links"]["questoes"]:
                link = link_info["url"]
                if link not in visitados and link not in fila:
                    if not apenas_questoes or re.search(r"/demo/questao/\d+/", link):
                        fila.append(link)

        if fila and len(visitados) < max_paginas:
            time.sleep(delay)

    links_pendentes = [l for l in fila if l not in visitados]

    resultado_final = {
        "meta": {
            "url_inicial":                url_inicial,
            "dominio_base":               dominio_base,
            "total_paginas_visitadas":    len(paginas_coletadas),
            "timestamp_inicio":           paginas_coletadas[0]["timestamp"] if paginas_coletadas else None,
            "timestamp_fim":              datetime.now().isoformat(),
            "links_pendentes_nao_visitados": links_pendentes,
        },
        "paginas": paginas_coletadas,
    }

    with open(arquivo_saida, "w", encoding="utf-8") as f:
        json.dump(resultado_final, f, ensure_ascii=False, indent=2)

    logger.info(
        f"\nCrawl concluído! "
        f"Páginas: {len(paginas_coletadas)} | "
        f"Pendentes: {len(links_pendentes)} | "
        f"Saída: {arquivo_saida}"
    )
    return resultado_final


# ─────────────────────────────────────────────
# EXECUÇÃO
# ─────────────────────────────────────────────

if __name__ == "__main__":
    # ── Configure aqui ──────────────────────────────────────────────────
    URL_INICIAL = "https://provaderesidencia.com.br/demo/questao/158978/abc-sp-2021-r1-1-questao-2"
    MAX_PAGINAS  = 5       # Quantas questões rastrear
    DELAY        = 1.5     # Pausa entre requisições (segundos)
    APENAS_QUESTOES = True # Se False, segue qualquer link do domínio
    # CRAWLER_SAIDA permite definir saída por env (útil em Docker/sandbox)
    ARQUIVO_SAIDA = os.getenv("CRAWLER_SAIDA", "resultado_crawl.json")
    # ────────────────────────────────────────────────────────────────────

    resultado = crawl(
        url_inicial=URL_INICIAL,
        max_paginas=MAX_PAGINAS,
        delay=DELAY,
        apenas_questoes=APENAS_QUESTOES,
        arquivo_saida=ARQUIVO_SAIDA,
    )

    # Resumo no console
    print("\n" + "=" * 65)
    print("RESUMO DO CRAWL")
    print("=" * 65)
    meta = resultado["meta"]
    print(f"URL inicial       : {meta['url_inicial']}")
    print(f"Páginas visitadas : {meta['total_paginas_visitadas']}")
    print(f"Links pendentes   : {len(meta['links_pendentes_nao_visitados'])}")

    for i, pag in enumerate(resultado["paginas"], 1):
        q = pag.get("questao")
        print(f"\n[{i}] {pag['titulo']}")
        print(f"  URL: {pag['url']}")

        if q:
            print(f"  Prova   : {q['prova']}")
            print(f"  Número  : {q['numero']}")
            print(f"  Estado  : {q['estado']}")
            if q.get("aviso"):
                print(f"  ⚠ Aviso : {q['aviso']}")
            print(f"  Enunciado: {q['enunciado'][:100]}...")
            print(f"  Imagem  : {q['imagem_enunciado'] or 'nenhuma'}")
            print(f"  Alternativas ({len(q['alternativas'])}):")
            for alt in q["alternativas"]:
                marcador = "✅" if alt["correta"] else "  "
                print(f"    {marcador} [{alt['letra']}] {alt['texto'][:80]}")
            if q["alternativa_correta"]:
                c = q["alternativa_correta"]
                print(f"  Gabarito oficial: Letra {c['letra']} (id={c['valor']})")
            else:
                print(f"  Gabarito oficial: não exibido pelo site")
        else:
            print(f"  (sem estrutura de questão)")

        print(f"  Links de questão: {len(pag['links']['questoes'])}")

    print(f"\nDados salvos em: {ARQUIVO_SAIDA}")
